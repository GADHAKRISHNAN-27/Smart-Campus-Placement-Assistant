from django.shortcuts import render
import pickle
import numpy as np
from django.contrib import messages
import os

def career(request):
    return render(request, "hometest.html")

# def predict(request):
#     if request.method == 'POST':
#         result = request.POST
#         print(result)
#         try:
#             # Convert form values to integers, ignoring non-integer values
#             arr = [int(value) for value in result.values() if value.isdigit()]
#             data = np.array(arr).reshape(1, -1)

#             print(data)

#             # Define the path to the model file
#             model_path = os.path.join(os.path.dirname(__file__), 'careerlast.pkl')

#             if not os.path.isfile(model_path):
#                 return render(request, "hometest.html", {'error': 'Model file not found'})

#             loaded_model = pickle.load(open(model_path, 'rb'))
#             predictions = loaded_model.predict(data)
#             pred = loaded_model.predict_proba(data)
#             pred = pred > 0.05

#             print("Predictions:", predictions)
#             print("Predicted Probabilities:", pred)

#             res = {}
#             final_res = {}
#             index = 0
#             for j in range(pred.shape[1]):
#                 if pred[0, j]:
#                     res[index] = j
#                     index += 1

#             print("Res Dictionary:", res)

#             index = 0
#             for key, value in res.items():
#                 if value != predictions[0]:
#                     final_res[index] = value
#                     print('final_res[index]:',final_res[index]) 
#                     index += 1

#             jobs_dict = {
#                 0: 'AI ML Specialist',
#                 1: 'API Integration Specialist',
#                 2: 'Application Support Engineer',
#                 3: 'Business Analyst',
#                 4: 'Customer Service Executive',
#                 5: 'Cyber Security Specialist',
#                 6: 'Data Scientist',
#                 7: 'Database Administrator',
#                 8: 'Graphics Designer',
#                 9: 'Hardware Engineer',
#                 10: 'Helpdesk Engineer',
#                 11: 'Information Security Specialist',
#                 12: 'Networking Engineer',
#                 13: 'Project Manager',
#                 14: 'Software Developer',
#                 15: 'Software Tester',
#                 16: 'Technical Writer'
#             }

#             job0 = predictions[0]
#             print("Job0:", job0)
#             print("Job0:", job0)

#             return render(request, "testafter.html", {'final_res': final_res, 'job_dict': jobs_dict, 'job0': job0})

#         except ValueError as e:
#             return render(request, "hometest.html", {'error': 'Invalid input data'})

#     return render(request, "hometest.html")











def predict(request):
    if request.method == 'POST':
        result = request.POST
        print(result)
        try:
            # Convert form values to integers, ignoring non-integer values
            arr = [int(value) for value in result.values() if value.isdigit()]
            data = np.array(arr).reshape(1, -1)

            print(data)

            # Define the path to the model file
            model_path = os.path.join(os.path.dirname(__file__), 'careerlast.pkl')

            if not os.path.isfile(model_path):
                return render(request, "hometest.html", {'error': 'Model file not found'})

            loaded_model = pickle.load(open(model_path, 'rb'))
            predictions = loaded_model.predict(data)
            pred = loaded_model.predict_proba(data)
            pred = pred > 0.05

            print("Predictions:", predictions)
            print("Predicted Probabilities:", pred)

            res = {}
            final_res = []
            index = 0
            for j in range(pred.shape[1]):
                if pred[0, j]:
                    res[index] = j
                    index += 1

            print("Res Dictionary:", res)

            for key, value in res.items():
                if value != predictions[0]:
                    final_res.append(value)
                    print('final_res[index]:', value)

            jobs_dict = {
                0: 'AI ML Specialist',
                1: 'API Integration Specialist',
                2: 'Application Support Engineer',
                3: 'Business Analyst',
                4: 'Customer Service Executive',
                5: 'Cyber Security Specialist',
                6: 'Data Scientist',
                7: 'Database Administrator',
                8: 'Graphics Designer',
                9: 'Hardware Engineer',
                10: 'Helpdesk Engineer',
                11: 'Information Security Specialist',
                12: 'Networking Engineer',
                13: 'Project Manager',
                14: 'Software Developer',
                15: 'Software Tester',
                16: 'Technical Writer'
            }

            job0 = predictions[0]
            print("Job0:", job0)

            # Prepare a list of job names for the final_res indices
            final_jobs = [jobs_dict.get(index) for index in final_res]

            messages.success(request, "Test result generated successfully!", extra_tags='log')

            return render(request, "testafter.html", {
                'final_res': final_res,
                'job_dict': jobs_dict,
                'job0': job0,
                'final_jobs': final_jobs
            })

        except ValueError as e:
            return render(request, "hometest.html", {'error': 'Invalid input data'})

    return render(request, "hometest.html")
