from django.shortcuts import render, redirect, get_object_or_404
from .forms import *
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from .models import *
from .forms import *
from django.views.generic import ListView
from company.models import Advertisement

def register_alumni(request):
    if request.method == 'POST':
        form = AlumniRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            alumni = form.save(commit=False)
            alumni.usertype = 2
            alumni.is_approved = True
            alumni.set_password(form.cleaned_data['password'])
            alumni.save()
            messages.success(request,f'Registered successfully. you can now login.', extra_tags='log')
            return redirect('/login')
    else:
        form = AlumniRegistrationForm()
    return render(request, 'register_alumni.html', {'form': form})

@login_required
def alumni_profile(request):
    user = get_object_or_404(Student, pk=request.user.pk) 
    return render(request, 'alumni_profile.html', {'user': user})

@login_required
def alumni_edit_form(request):
    user = get_object_or_404(Student, pk=request.user.pk)
    if request.method == 'POST':
        form = AlumniProfileForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully',extra_tags='log')
            return redirect('/alumni_profile') 
    else:
        form = AlumniProfileForm(instance=user)
    return render(request, 'alumni_edit_form.html', {'form': form})

@login_required
def alumni_dashboard(request):
    advertisements = Advertisement.objects.filter(is_active=True)
    return render(request, 'alumni_dashboard.html', {'user': request.user, 'advertisements': advertisements})


# Networking events
class ListEvents(ListView):
    model = NetworkingEvent
    template_name = 'list_events.html'
    context_object_name = 'events'

@login_required
def create_event(request):
    if request.method == 'POST':
        form = NetworkingEventForm(request.POST)
        if form.is_valid():
            event = form.save(commit=False)
            if request.user.usertype in [1, 2]:
                print(request.user.usertype)
                event.save()
                messages.success(request, 'Event created successfully!',extra_tags='con')
                return redirect('/list_events')
            else:
                messages.error(request, 'You do not have permission to create an event.',extra_tags='con')
                return redirect('/list_events')
        else:
            messages.error(request, 'There was an error in the form. Please correct the errors and try again.',extra_tags='con')
    else:
        form = NetworkingEventForm()
    
    return render(request, 'create_event.html', {'form': form})

@login_required
def event_detail(request, pk):
    event = NetworkingEvent.objects.get(pk=pk)
    return render(request, 'event_detail.html', {'event': event})

@login_required
def edit_event(request, pk):
    event = get_object_or_404(NetworkingEvent, pk=pk)

    # Check if the user has the necessary permissions
    if request.user.usertype not in [1, 2]:
        messages.error(request, 'You do not have permission to edit this event.', extra_tags='con')
        return redirect('event_detail', pk=pk)

    if request.method == 'POST':
        form = NetworkingEventForm(request.POST, instance=event)
        if form.is_valid():
            form.save()
            messages.success(request, 'Event updated successfully!', extra_tags='con')
            return redirect('event_detail', pk=pk)
        else:
            messages.error(request, 'There was an error in the form. Please correct the errors and try again.', extra_tags='con')
    else:
        form = NetworkingEventForm(instance=event)

    return render(request, 'edit_event.html', {'form': form, 'event': event})

@login_required
def delete_event(request, pk):
    event = NetworkingEvent.objects.get(pk=pk)
    if request.user.usertype in [1, 2]:
        event.delete()
        messages.success(request, 'Event deleted successfully!',extra_tags='con')
        return redirect('/list_events')
    else:
        messages.error(request, 'You do not have permission to delete an event.',extra_tags='con')
        return redirect('/list_events')
    


# job openings
@login_required
def create_job_opening(request):
    if request.user.usertype == 2:
        if request.method == 'POST':
            form = JobOpeningForm(request.POST)
            if form.is_valid():
                job_opening = form.save(commit=False)
                job_opening.posted_by = request.user
                job_opening.save()
                messages.success(request, 'Job opening created successfully!', extra_tags='con')
                return redirect('/job_opening_list')
        else:
            form = JobOpeningForm()
        return render(request, 'create_job_opening.html', {'form': form})
    return redirect('/alumni_dashboard')

@login_required
def job_opening_list(request):
    job_openings = JobOpening.objects.all()
    return render(request, 'job_opening_list.html', {'job_openings': job_openings})

@login_required
def job_opening_detail(request, pk):
    job_opening = JobOpening.objects.get(pk=pk)
    return render(request, 'job_opening_detail.html', {'job_opening': job_opening})

@login_required
def edit_job_opening(request, pk):
    job_opening = get_object_or_404(JobOpening, pk=pk)

    # Check if the user has the necessary permissions 
    if request.user != job_opening.posted_by and request.user.usertype != 2:
        return redirect('/alumni_dashboard')

    if request.method == 'POST':
        form = JobOpeningForm(request.POST, instance=job_opening)
        if form.is_valid():
            form.save()
            messages.success(request, 'Job opening updated successfully!', extra_tags='con')
            return redirect('job_opening_detail', pk=pk)
        else:
            messages.error(request, 'There was an error in the form. Please correct the errors and try again.', extra_tags='con')
    else:
        form = JobOpeningForm(instance=job_opening)

    return render(request, 'edit_job_opening.html', {'form': form, 'job_opening': job_opening})

@login_required
def delete_job_opening(request, pk):
    job_opening = JobOpening.objects.get(pk=pk)
    if request.user.usertype in [1, 2]:
        job_opening.delete()
        messages.success(request, 'Job opening deleted successfully!',extra_tags='con')
        return redirect('/job_opening_list')
    else:
        messages.error(request, 'You do not have permission to delete a job opening.',extra_tags='con')
        return redirect('/job_opening_list')
    



# Career Advice View
@login_required
def create_career_advice(request):
    if request.user.usertype == 2:  
        if request.method == 'POST':
            form = CareerAdviceForm(request.POST)
            if form.is_valid():
                career_advice = form.save(commit=False)
                career_advice.given_by = request.user
                career_advice.save()
                messages.success(request, 'Career advice created successfully!', extra_tags='con')
                return redirect('/career_advice_list')
        else:
            form = CareerAdviceForm()
        return render(request, 'create_career_advice.html', {'form': form})
    return redirect('/alumni_dashboard') 

@login_required
def career_advice_list(request):
    career_advice_list = CareerAdvice.objects.all()
    return render(request, 'career_advice_list.html', {'career_advice_list': career_advice_list})

@login_required
def edit_career_advice(request, pk):
    career_advice = get_object_or_404(CareerAdvice, pk=pk)

    # Check if the user has the necessary permissions 
    if request.user != career_advice.given_by and request.user.usertype != 2:
        return redirect('/alumni_dashboard')

    if request.method == 'POST':
        form = CareerAdviceForm(request.POST, instance=career_advice)
        if form.is_valid():
            form.save()
            messages.success(request, 'Career Advice updated successfully!', extra_tags='con')
            return redirect('career_advice_list')
        else:
            messages.error(request, 'There was an error in the form. Please correct the errors and try again.', extra_tags='con')
    else:
        form = CareerAdviceForm(instance=career_advice)

    return render(request, 'edit_career_advice.html', {'form': form, 'career_advice': career_advice})

@login_required
def delete_career_advice(request, pk):
    carrer_advice = CareerAdvice.objects.get(pk=pk)
    if request.user.usertype in [1, 2]:
        carrer_advice.delete()
        messages.success(request, 'Career Advice deleted successfully!',extra_tags='con')
        return redirect('/career_advice_list')
    else:
        messages.error(request, 'You do not have permission to delete the career advice.',extra_tags='con')
        return redirect('/career_advice_list')
    



# Success Story View
@login_required
def create_success_story(request):
    if request.user.usertype == 2: 
        if request.method == 'POST':
            form = SuccessStoryForm(request.POST)
            if form.is_valid():
                success_story = form.save(commit=False)
                success_story.alumni = request.user
                success_story.save()
                messages.success(request, 'Success Story created successfully!', extra_tags='con')
                return redirect('/success_story_list')
        else:
            form = SuccessStoryForm()
        return render(request, 'create_success_story.html', {'form': form})
    return redirect('/alumni_dashboard')  

@login_required
def success_story_list(request):
    success_stories = SuccessStory.objects.all()
    return render(request, 'success_story_list.html', {'success_stories': success_stories})

@login_required
def success_story_detail(request,pk):
    story = SuccessStory.objects.get(pk=pk)
    return render(request, 'success_story_detail.html', {'story': story})

@login_required
def edit_success_story(request, pk):
    success_story = SuccessStory.objects.get(pk=pk)
    if request.user.usertype == 2:
        if request.method == 'POST':
            form = SuccessStoryForm(request.POST, instance=success_story)
            if form.is_valid():
                form.save()
                messages.success(request, 'Success Story updated successfully!', extra_tags='con')
                return redirect('/success_story_list')
            else:
                messages.error(request, 'Failed to update success story. Please correct the errors and try again.', extra_tags='con')
        else:
            form = SuccessStoryForm(instance=success_story)
    else:
        messages.error(request, 'You do not have permission to edit the success story.', extra_tags='con')
        return redirect('/success_story_list')
    
    return render(request, 'edit_success_story.html', {'form': form, 'success_story': success_story})

@login_required
def delete_success_story(request,pk):
    success_story = SuccessStory.objects.get(pk=pk)
    if request.user.usertype in [1,2]:
        success_story.delete()
        messages.success(request, 'Success Story deleted successfully!', extra_tags='con')
        return redirect('/success_story_list')
    else:
        messages.error(request, 'You do not have permission to delete the success story.', extra_tags='con')
        return redirect('/success_story_list')
    



# Placement Testimonial View
@login_required
def create_placement_testimonial(request):
    if request.user.usertype == 2: 
        if request.method == 'POST':
            form = PlacementTestimonialForm(request.POST)
            if form.is_valid():
                testimonial = form.save(commit=False)
                testimonial.alumni = request.user
                testimonial.save()
                messages.success(request, 'Your testimonial was created successfully!', extra_tags='con')
                return redirect('/placement_testimonial_list')
            else:
                messages.error(request, 'Failed to create testimonial. Please correct the errors and try again.', extra_tags='con')
        else:
            form = PlacementTestimonialForm()
        return render(request, 'create_placement_testimonial.html', {'form': form})
    else:
        messages.error(request, 'You do not have permission to create a testimonial.', extra_tags='con')
        return redirect('/placement_testimonial_list')

@login_required
def placement_testimonial_list(request):
    placement_testimonials = PlacementTestimonial.objects.all()
    return render(request, 'placement_testimonial_list.html', {'placement_testimonials': placement_testimonials})

@login_required
def edit_placement_testimonial(request,pk):
    placement_testimonial = PlacementTestimonial.objects.get(pk=pk)
    if request.user.usertype == 2:
        if request.method == 'POST':
            form = PlacementTestimonialForm(request.POST, instance=placement_testimonial)
            if form.is_valid():
                form.save()
                messages.success(request, 'Placement Testimonial updated successfully!', extra_tags='con')
                return redirect('/placement_testimonial_list')
            else:
                messages.error(request, 'Error updating Placement Testimonial.', extra_tags='con')
                return render(request, 'edit_placement_testimonial.html', {'form': form})
        else:
            form = PlacementTestimonialForm(instance=placement_testimonial)
            return render(request, 'edit_placement_testimonial.html', {'form': form})
    return redirect('/placement_testimonial_list')

@login_required
def delete_placement_testimonial(request,pk):
    placement_testimonial = PlacementTestimonial.objects.get(pk=pk)
    if request.user.usertype == 2:
        placement_testimonial.delete()
        messages.success(request, 'Placement Testimonial deleted successfully!', extra_tags='con')
        return redirect('/placement_testimonial_list')
    return redirect('/alumni_dashboard')
