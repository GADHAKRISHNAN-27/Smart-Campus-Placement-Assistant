from django import forms
from django.core.exceptions import ValidationError
from django.utils import timezone
from student.models import Student
from administrator.models import Course, Specialization
from .models import *
import re
from django.core.validators import validate_email



class AlumniRegistrationForm(forms.ModelForm):
    confirm_password = forms.CharField(
        required=True,
        widget=forms.PasswordInput(attrs={'class': 'form-control text-dark', 'placeholder': 'Confirm Password'})
    )
    password = forms.CharField(
        required=True,
        widget=forms.PasswordInput(attrs={'class': 'form-control text-dark', 'placeholder': 'Password'})
    )
    phone = forms.IntegerField(
        required=True,
        widget=forms.NumberInput(attrs={'class': 'form-control text-dark', 'id': 'id_contact', 'placeholder': 'Phone'})
    )
    graduation_year = forms.IntegerField(
        required=True,
        widget=forms.NumberInput(attrs={'class': 'form-control text-dark', 'placeholder': 'Graduation Year'})
    )
    image = forms.ImageField(
        required=False,
        widget=forms.ClearableFileInput(attrs={'class': 'form-control-file bg-light'})
    )
    course = forms.ModelChoiceField(
        queryset=Course.objects.all(),
        required=True,
        widget=forms.Select(attrs={'class': 'form-control text-dark', 'placeholder': 'Select course'}),
        empty_label='Select course'
    )
    specialization = forms.ModelChoiceField(
        queryset=Specialization.objects.all(),
        required=True,
        widget=forms.Select(attrs={'class': 'form-control text-dark', 'placeholder': 'Select Specialization'}),
        empty_label='Select specialization'
    )
    job_title = forms.CharField(
        max_length=255,
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control text-dark', 'placeholder': 'Job Title'})
    )
    company = forms.CharField(
        max_length=255,
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control text-dark', 'placeholder': 'Company'})
    )

    class Meta:
        model = Student
        fields = ['username', 'email', 'phone', 'graduation_year', 'course', 'specialization', 'job_title', 'company', 'image', 'password', 'confirm_password']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control text-dark', 'placeholder': 'Name', 'required': 'True'}),
            'email': forms.EmailInput(attrs={'class': 'form-control text-dark', 'placeholder': 'Email'}),
        }
        help_texts = {
            'username': None,
            'email': None,
            'phone': None,
            'graduation_year': None,
            'course': None,
            'specialization': None,
            'job_title': None,
            'company': None,
            'image': None
        }

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if not username.isalpha():
            raise ValidationError("Username should only contain letters.")
        return username

    def clean_phone(self):
        phone = self.cleaned_data.get('phone')

        # Convert phone to a string for validation
        phone_str = str(phone)

        # Check the length of the phone number (must be exactly 10 digits)
        if len(phone_str) != 10:
            raise forms.ValidationError("Phone number must be exactly 10 digits.")

        # Check if the phone number starts with 6, 7, 8, or 9
        if phone_str[0] not in ['6', '7', '8', '9']:
            raise forms.ValidationError("Phone number must start with 6, 7, 8, or 9.")

        return phone

    
    def clean_email(self):
        cleaned_email = self.cleaned_data.get('email')
        
        # Validate the structure of the email
        try:
            validate_email(cleaned_email)
        except ValidationError:
            raise forms.ValidationError("Invalid email format.")
        
        if '@' not in cleaned_email:
            raise ValidationError('Please enter a valid email address.')
        
        # Check if the email is already registered
        if Student.objects.filter(email=cleaned_email).exists():
            raise forms.ValidationError("This email is already registered.")
        
        return cleaned_email

    def clean_graduation_year(self):
        graduation_year = self.cleaned_data.get('graduation_year')
        current_year = timezone.now().year
        if graduation_year and (graduation_year < 1900 or graduation_year > current_year):
            raise ValidationError("Graduation year must be between 1900 and the current year.")
        return graduation_year

    def clean_password(self):
        password = self.cleaned_data.get('password')
        if len(password) < 8 or len(password) > 12:
            raise forms.ValidationError("Password must be between 8 and 12 characters long.")
        if not re.search(r'[A-Z]', password):
            raise forms.ValidationError("Password must contain at least one uppercase letter.")
        if not re.search(r'[a-z]', password):
            raise forms.ValidationError("Password must contain at least one lowercase letter.")
        if not re.search(r'[0-9]', password):
            raise forms.ValidationError("Password must contain at least one digit.")
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            raise forms.ValidationError("Password must contain at least one special character.")
        return password

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        if password and confirm_password and password != confirm_password:
            raise forms.ValidationError("Passwords do not match. Please enter again.")
        return cleaned_data


class AlumniProfileForm(forms.ModelForm):
    course = forms.ModelChoiceField(
        queryset=Course.objects.all(),
        required=True,
        widget=forms.Select(attrs={'class': 'form-control', 'placeholder': 'Select course'}),
        empty_label='Select course'
    )
    specialization = forms.ModelChoiceField(
        queryset=Specialization.objects.all(),
        required=True,
        widget=forms.Select(attrs={'class': 'form-control', 'placeholder': 'Select Specialization'}),
        empty_label='Select specialization'
    )
    graduation_year = forms.IntegerField(
        required=True,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Graduation Year'})
    )

    class Meta:
        model = Student
        fields = ['username', 'email', 'phone', 'graduation_year', 'course', 'specialization', 'job_title', 'company', 'image']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Username'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Email'}),
            'phone': forms.NumberInput(attrs={'class': 'form-control', 'id': 'id_contact', 'placeholder': 'Phone'}),
            'job_title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Job Title'}),
            'company': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Company'})
        }
        help_texts = {
            'username': None,
            'email': None,
            'phone': None,
            'graduation_year': None,
            'course': None,
            'specialization': None,
            'job_title': None,
            'company': None
        }

    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        
        # Check if the phone contains only digits
        if not phone.isdigit():
            raise forms.ValidationError("Phone number must contain only digits.")
        
        # Check the length of the phone number (must be exactly 10 digits)
        if len(phone) != 10:
            raise forms.ValidationError("Phone number must be exactly 10 digits.")
        
        # Check if the phone number starts with 6, 7, 8, or 9
        if phone[0] not in ['6', '7', '8', '9']:
            raise forms.ValidationError("Phone number must start with 6, 7, 8, or 9.")
        
        return phone
    

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if not username.isalpha():
            raise ValidationError("Username should only contain letters.")
        return username
    
    def clean_email(self):
        cleaned_email = self.cleaned_data.get('email')
        
        # Validate the structure of the email
        try:
            validate_email(cleaned_email)
        except ValidationError:
            raise forms.ValidationError("Invalid email format.")
        
        if '@' not in cleaned_email:
            raise ValidationError('Please enter a valid email address.')
        
        # Check if the email is already registered
        if Student.objects.filter(email=cleaned_email).exists():
            raise forms.ValidationError("This email is already registered.")
        
        return cleaned_email


class NetworkingEventForm(forms.ModelForm):
    attendees = forms.ChoiceField(
        choices=NetworkingEvent.ATTENDEE_CHOICES,
        widget=forms.Select(attrs={'class': 'select-with-icon text-dark bg-white'}),
    )

    class Meta:
        model = NetworkingEvent
        fields = ['title', 'date', 'location', 'description', 'attendees']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control bg-white', 'placeholder': 'Event Title'}),
            'date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control bg-white', 'placeholder': 'Event Date'}),
            'location': forms.TextInput(attrs={'class': 'form-control bg-white', 'placeholder': 'Event Location'}),
            'description': forms.Textarea(attrs={'class': 'form-control bg-white', 'placeholder': 'Event Description'}),
        }

    def clean_date(self):
        date = self.cleaned_data.get('date')
        if date and date < timezone.now().date():
            raise forms.ValidationError('The Event date cannot be in the past.')
        return date


class JobOpeningForm(forms.ModelForm):
    class Meta:
        model = JobOpening
        fields = ['title', 'description', 'company']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control bg-white', 'placeholder': 'Title'}),
            'description': forms.Textarea(attrs={'class': 'form-control bg-white', 'placeholder': 'Description'}),
            'company': forms.TextInput(attrs={'class': 'form-control bg-white', 'placeholder': 'Company'})
        }

    # def clean_company(self):
    #     company = self.cleaned_data.get('company')
    #     if not company.isalpha():
    #         raise ValidationError('Company name should only contain letters.')
    #     return company


class CareerAdviceForm(forms.ModelForm):
    class Meta:
        model = CareerAdvice
        fields = ['advice']
        widgets = {
            'advice': forms.Textarea(attrs={'class': 'form-control bg-light', 'placeholder': 'Advice'}),
        }

    def clean_advice(self):
        advice = self.cleaned_data.get('advice')
        if len(advice) < 10:
            raise ValidationError('Advice must be at least 10 characters long.')
        return advice


class SuccessStoryForm(forms.ModelForm):
    class Meta:
        model = SuccessStory
        fields = ['title', 'story']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control bg-light', 'placeholder': 'Title'}),
            'story': forms.Textarea(attrs={'class': 'form-control bg-light', 'placeholder': 'Story'})
        }

    def clean_title(self):
        title = self.cleaned_data.get('title')
        if len(title) < 5:
            raise ValidationError('Title must be at least 5 characters long.')
        return title

    def clean_story(self):
        story = self.cleaned_data.get('story')
        if len(story) < 20:
            raise ValidationError('Story must be at least 20 characters long.')
        return story


class PlacementTestimonialForm(forms.ModelForm):
    class Meta:
        model = PlacementTestimonial
        fields = ['testimonial']
        widgets = {
            'testimonial': forms.Textarea(attrs={'class': 'form-control bg-light', 'placeholder': 'Testimonial'})
        }

    def clean_testimonial(self):
        testimonial = self.cleaned_data.get('testimonial')
        if len(testimonial) < 10:
            raise ValidationError('Testimonial must be at least 10 characters long.')
        return testimonial
