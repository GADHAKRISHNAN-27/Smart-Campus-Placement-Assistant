from django.db import models
from student.models import Student
from django.utils import timezone
from django.core.exceptions import ValidationError


class NetworkingEvent(models.Model):
    ATTENDEE_CHOICES = [
        ('student', 'Student'),
        ('alumni', 'Alumni'),
        ('companies', 'Companies'),
        ('student_alumni', 'Students & Alumni'),
        ('student_companies', 'Students & Companies'),
        ('alumni_companies', 'Alumni & Companies'),
        ('all', 'All')
    ]
    title = models.CharField(max_length=255)
    date = models.DateField(default='')
    location = models.CharField(max_length=255)
    description = models.TextField()
    attendees = models.CharField(
        max_length=20,
        choices=ATTENDEE_CHOICES,
        default='all',
    )
    created_at = models.DateTimeField(auto_now_add=True)
    organized_by = models.ForeignKey(Student, on_delete=models.CASCADE, null=True)


    def __str__(self):
        return self.get_attendees_display()
    
    
    def clean(self):
        super().clean()
        if self.date and self.date < timezone.now().date():
            raise ValidationError('The Event starting cannot be in the past.')


class JobOpening(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    company = models.CharField(max_length=255)
    date_posted = models.DateTimeField(auto_now_add=True)
    posted_by = models.ForeignKey(Student, on_delete=models.CASCADE)

class CareerAdvice(models.Model):
    advice = models.TextField()
    given_by = models.ForeignKey(Student, on_delete=models.CASCADE)
    date_given = models.DateTimeField(auto_now_add=True)

class SuccessStory(models.Model):
    title = models.CharField(max_length=255)
    story = models.TextField()
    alumni = models.ForeignKey(Student, on_delete=models.CASCADE)
    date_posted = models.DateTimeField(auto_now_add=True)

class PlacementTestimonial(models.Model):
    testimonial = models.TextField()
    alumni = models.ForeignKey(Student, on_delete=models.CASCADE)
    date_posted = models.DateTimeField(auto_now_add=True)
