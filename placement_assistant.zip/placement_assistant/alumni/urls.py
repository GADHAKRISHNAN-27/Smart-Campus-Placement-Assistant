from django.urls import path
from . import views
from .views import ListEvents

urlpatterns = [
    path('register_alumni', views.register_alumni, name='register_alumni'),

    path('alumni_dashboard',views.alumni_dashboard,name='alumni_dashboard'),

    path('alumni_profile', views.alumni_profile, name='alumni_profile'),
    path('alumni_edit_form',views.alumni_edit_form,name='alumni_edit_form'),

    path('list_events', ListEvents.as_view(), name='list_events'),
    path('create_event', views.create_event, name='create_event'),
    path('event_detail/<int:pk>', views.event_detail, name='event_detail'),
    path('edit_event/<int:pk>', views.edit_event, name='edit_event'),
    path('delete_event/<int:pk>', views.delete_event,name='delete_event'),


    path('job_opening_list', views.job_opening_list, name='job_opening_list'),
    path('create_job_opening', views.create_job_opening, name='create_job_opening'),
    path('job_opening_detail/<int:pk>', views.job_opening_detail, name='job_opening_detail'),
    path('edit_job_opening/<int:pk>/', views.edit_job_opening, name='edit_job_opening'),
    path('delete_job_opening/<int:pk>',views.delete_job_opening,name='delete_job_opening'),

    path('career_advice_list', views.career_advice_list, name='career_advice_list'),
    path('create_career_advice', views.create_career_advice, name='create_career_advice'),
    path('delete_career_advice/<int:pk>',views.delete_career_advice,name='delete_career_advice'),
    path('edit_career_advice/<int:pk>', views.edit_career_advice,name='edit_career_advice'),

    path('success_story_list', views.success_story_list, name='success_story_list'),
    path('create_success_story', views.create_success_story, name='create_success_story'),
    path('delete_success_story/<int:pk>',views.delete_success_story,name='delete_success_story'),
    path('edit_success_story/<int:pk>', views.edit_success_story,name='edit_success_story'),
    path('success_story_detail/<int:pk>', views.success_story_detail,name='success_story_detail'),

    path('placement_testimonial_list', views.placement_testimonial_list, name='placement_testimonial_list'),
    path('create_placement_testimonial', views.create_placement_testimonial, name='create_placement_testimonial'),
    path('delete_placement_testimonial/<int:pk>',views.delete_placement_testimonial,name='delete_placement_testimonial'),
    path('edit_placement_testimonial/<int:pk>', views.edit_placement_testimonial,name='edit_placement_testimonial'),
]

