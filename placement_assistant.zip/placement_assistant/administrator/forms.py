from django import forms
from django.core.exceptions import ValidationError
from .models import *

class AdminProfileForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['username', 'email', 'phone', 'image']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control bg-light text-dark', 'placeholder': 'Username'}),
            'email': forms.EmailInput(attrs={'class': 'form-control bg-light text-dark', 'placeholder': 'Email'}),
            'phone': forms.NumberInput(attrs={'class': 'form-control bg-light text-dark', 'id': 'id_contact', 'placeholder': 'Phone'}),
            'image': forms.ClearableFileInput(attrs={'class': 'form-control-file bg-light '}),
        }
        help_texts = {
            'username': None,
            'email': None,
            'phone': None,
            'image': None,
        }

    # Field-level validation for username
    def clean_username(self):
        username = self.cleaned_data.get('username')
        if not username.isalnum():
            raise ValidationError('Username should only contain alphanumeric characters.')
        return username

    # Field-level validation for email
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if '@' not in email:
            raise ValidationError('Please enter a valid email address.')
        return email

    # Field-level validation for phone
    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        
        # Check if the phone contains only digits
        if not phone.isdigit():
            raise forms.ValidationError("Phone number must contain only digits.")
        
        # Check the length of the phone number (must be exactly 10 digits)
        if len(phone) != 10:
            raise forms.ValidationError("Phone number must be exactly 10 digits.")
        
        # Check if the phone number starts with 6, 7, 8, or 9
        if phone[0] not in ['6', '7', '8', '9']:
            raise forms.ValidationError("Phone number must start with 6, 7, 8, or 9.")
        
        return phone


class NewsUpdateForm(forms.ModelForm):
    class Meta:
        model = NewsUpdate
        fields = ['title', 'content']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control bg-light text-dark', 'placeholder': 'Title'}),
            'content': forms.Textarea(attrs={'class': 'form-control bg-light text-dark', 'placeholder': 'Content'}),
        }

    # Field-level validation for title
    def clean_title(self):
        title = self.cleaned_data.get('title')
        if len(title) < 5:
            raise ValidationError('Title must be at least 5 characters long.')
        return title

    # Field-level validation for content
    def clean_content(self):
        content = self.cleaned_data.get('content')
        if len(content) < 10:
            raise ValidationError('Content must be at least 10 characters long.')
        return content


class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['course_name']
        widgets = {
            'course_name': forms.TextInput(attrs={'class': 'form-control bg-light text-dark', 'placeholder': 'Enter course name'}),
        }

    # Field-level validation for course_name
    def clean_course_name(self):
        course_name = self.cleaned_data.get('course_name')
        if not course_name.isalpha():
            raise ValidationError('Course name should only contain letters.')
        return course_name


class SpecializationForm(forms.ModelForm):
    class Meta:
        model = Specialization
        fields = ['specialization_name']
        widgets = {
            'specialization_name': forms.TextInput(attrs={'class': 'form-control bg-light text-dark', 'placeholder': 'Enter specialization name'}),
        }

    # Field-level validation for specialization_name
    def clean_specialization_name(self):
        specialization_name = self.cleaned_data.get('specialization_name')
        if len(specialization_name) < 3:
            raise ValidationError('Specialization name must be at least 3 characters long.')
        return specialization_name
