from django.db import models
from student.models import Student

class Course(models.Model):
    course_name = models.CharField(max_length=200, default='', null=True)
    def __str__(self):
        return self.course_name

class Specialization(models.Model):
    specialization_name = models.CharField(max_length=200, default='', null=True)
    def __str__(self):
        return self.specialization_name

class PlacementStatistics(models.Model):
    company_name = models.CharField(max_length=255, default='')
    student_count = models.IntegerField(default=50)

    def __str__(self):
        return self.company_name

class NewsUpdate(models.Model):
    title = models.CharField(max_length=255)
    content = models.TextField()
    date_published = models.DateTimeField(auto_now_add=True)

