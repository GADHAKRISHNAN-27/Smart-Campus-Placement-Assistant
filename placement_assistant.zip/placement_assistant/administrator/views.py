from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.conf import settings
from .models import *
from .forms import *
from student.models import Student, UserQueries, CompanyReview
from company.models import JobPosting
import json
from django.db.models import Count
from django.views.generic import ListView
from django.contrib import messages


@login_required
def admin_dashboard(request):
    # Query for companies and jobs waiting for approval
    companies = Student.objects.filter(is_approved=False)
    jobs = JobPosting.objects.filter(is_approved=False)

    # Aggregate data for the histogram
    company_stats = Student.objects.values('company_name').annotate(student_count=Count('id')).order_by('company_name')
    print(company_stats)
    # Prepare data for the histogram
    company_names = [stat['company_name'] for stat in company_stats]
    print(company_names)
    student_counts = [stat['student_count'] for stat in company_stats]
    print(student_counts)
    # Serialize data to JSON
    company_names_json = json.dumps(company_names)
    print(company_names_json)
    student_counts_json = json.dumps(student_counts)
    print(student_counts_json)

    # Pass the queried data to the template
    return render(request, 'admin_dashboard.html', {
        'companies': companies,
        'jobs': jobs,
        'company_names': company_names_json,
        'student_counts': student_counts_json,
    })



@login_required
def admin_profile(request):
    user = get_object_or_404(Student, pk=request.user.pk) 
    return render(request, 'admin_profile.html', {'user': user})

@login_required
def admin_edit_form(request):
    user = get_object_or_404(Student, pk=request.user.pk) 
    if request.method == 'POST':
        form = AdminProfileForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, f'Your profile is updated successfully!',extra_tags='edit')
            return redirect('/admin_profile') 
    else:
        form = AdminProfileForm(instance=user)
    return render(request, 'admin_edit_form.html', {'form': form})



@login_required
def add_course(request):
    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, f'Course added successfully!',extra_tags='log')
            return redirect('/course_and_specialization_list')  
    else:
        form = CourseForm()
    return render(request, 'add_course.html', {'form': form})

@login_required
def add_specialization(request):
    if request.method == 'POST':
        form = SpecializationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, f'Specialization added successfully!',extra_tags='log')
            return redirect('/course_and_specialization_list') 
    else:
        form = SpecializationForm()
    return render(request, 'add_specialization.html', {'form': form})

@login_required
def course_and_specialization_list(request):
    courses = Course.objects.all()
    specializations = Specialization.objects.all()
    
    return render(request, 'course_and_specialization_list.html', {
        'courses': courses,
        'specializations': specializations
    })

@login_required
def delete_course(request, course_id):
    course = Course.objects.get(id=course_id)
    course.delete()
    messages.success(request, f'Course deleted successfully!',extra_tags='log')
    return redirect('/course_and_specialization_list') 

@login_required
def delete_specialization(request, specialization_id):
    specialization = Specialization.objects.get(id=specialization_id)
    specialization.delete()
    messages.success(request, f'Specialization deleted successfully!',extra_tags='log')
    return redirect('/course_and_specialization_list') 


@login_required
def approve_company(request, company_id):
    company = get_object_or_404(Student, id=company_id)
    company.is_approved = True
    company.save()
    messages.success(request, f'Successfully approved the company and mail is send.',extra_tags='log')

    # Send approval email
    subject = 'Company Registration Approved'
    message = f'Dear {company.company_name},\n\nYour Company registration has been approved.\n\nThank you for registering with us! You can now login with your credentials...'
    recipient = company.email
    send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [recipient])

    return redirect('/admin_dashboard')

@login_required
def reject_company(request, company_id):
    company = get_object_or_404(Student, id=company_id)
    
    # Send rejection email before deleting the company record
    subject = 'Company Registration Rejected'
    message = f'Dear {company.name},\n\nWe regret to inform you that your company registration has been rejected.\n\nPlease contact us for more details about the reason for rejection..'
    recipient = company.email
    send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [recipient])

    company.delete()
    messages.success(request, f'Successfully Rejected the company and mail is send.',extra_tags='log')
    return redirect('/admin_dashboard')

@login_required
def approve_job(request, job_id):
    job = get_object_or_404(JobPosting, id=job_id)
    job.is_approved = True
    job.save()
    messages.success(request, f'Successfully approved the job and mail is send.',extra_tags='log')

    # Send approval email to the company
    company_name = job.company.company_name  
    company_email = job.company.email 
    job_title = job.title 

    subject = 'Job Posting Approved'
    message = f"""
    Dear {company_name},

    We are pleased to inform you that your job posting titled "{job_title}" has been approved and is now live on our platform.

    Thank you for choosing our platform to reach potential candidates.

    Best regards,
    Your Company Team
    """
    send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [company_email])

    return redirect('/admin_dashboard')

@login_required
def reject_job(request, job_id):
    job = get_object_or_404(JobPosting, id=job_id)

    # Send rejection email to the company before deleting the job posting
    company_name = job.company.company_name  
    company_email = job.company.email 
    job_title = job.title 

    subject = 'Job Posting Rejected'
    message = f"""
    Dear {company_name},

    We regret to inform you that your job posting titled "{job_title}" has been rejected. 

    If you have any questions or need further assistance, please feel free to contact us.

    Best regards,
    Your Company Team
    """
    send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [company_email])

    # Delete the job posting after sending the email
    job.delete()
    messages.success(request, f'Successfully rejected the job and mail is send.',extra_tags='log')
    return redirect('/admin_dashboard')



@login_required
def manage_students(request):
    print("sdf")
    users = Student.objects.filter(usertype=3)
    print(users)
    return render(request, 'manage_students.html', {'users': users})

@login_required
def manage_companies(request):
    companies = Student.objects.filter(usertype=1,is_approved=True)
    return render(request, 'manage_companies.html', {'companies': companies})

@login_required
def manage_alumnis(request):
    alumnis = Student.objects.filter(usertype=2)
    return render(request, 'manage_alumnis.html', {'alumnis': alumnis})



@login_required
def manage_news(request):
    if request.method == 'POST':
        form = NewsUpdateForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,f'News added Successfully.', extra_tags='log')
            return redirect('/manage_news')
    else:
        form = NewsUpdateForm()
    news_updates = NewsUpdate.objects.all()
    return render(request, 'manage_news.html', {'form': form, 'news_updates': news_updates})

@login_required
def delete_news(request, id):
    news = get_object_or_404(NewsUpdate, id=id)
    news.delete()
    messages.success(request,f'News deleted Successfully.', extra_tags='log')
    return redirect('/manage_news') 

@login_required
def edit_news(request, id):
    # news = get_object_or_404(NewsUpdate, id=id)
    news = NewsUpdate.objects.get(id=id)
    if request.method == 'POST':
        form = NewsUpdateForm(request.POST, instance=news)
        if form.is_valid():
            form.save()
            messages.success(request,f'News updated Successfully.', extra_tags='log')
            return redirect('/manage_news')
        else:
            return render(request, 'edit_news.html', {'form': form, 'news': news})
    else:
        form = NewsUpdateForm(instance=news)
        return render(request, 'edit_news.html', {'form': form, 'news': news})
    


@login_required
def moderate_reviews(request):
    reviews = CompanyReview.objects.all()
    return render(request,'moderate_reviews.html',{'reviews':reviews})

@login_required
def delete_review(request,id):
    review = CompanyReview.objects.filter(id=id)
    review.delete()
    messages.success(request,f"Review removed successfully.",extra_tags='log')
    return redirect('moderate_reviews')


class UserQuery(ListView):
    model = UserQueries
    template_name = 'query_view.html'
    context_object_name = 'queries'
    ordering = ['-id']



