from django.urls import path
from . import views
from  .views import UserQuery

urlpatterns = [
    path('admin_dashboard', views.admin_dashboard, name='admin_dashboard'),

    path('admin_profile', views.admin_profile,name='admin_profile'),
    path('admin_edit_form',views.admin_edit_form,name='admin_edit_form'),

    path('add_course', views.add_course, name='add_course'),
    path('add_specialization', views.add_specialization, name='add_specialization'),
    path('course_and_specialization_list',views.course_and_specialization_list,name='course_and_specialization_list'),
    path('delete_course/<int:course_id>/', views.delete_course, name='delete_course'),
    path('delete_specialization/<int:specialization_id>/', views.delete_specialization, name='delete_specialization'),

    path('approve_company/<int:company_id>/', views.approve_company, name='approve_company'),
    path('reject_company/<int:company_id>/', views.reject_company, name='reject_company'),

    path('approve_job/<int:job_id>/', views.approve_job, name='approve_job'),
    path('reject_job/<int:job_id>/', views.reject_job, name='reject_job'),

    path('manage_students', views.manage_students, name='manage_students'),
    path('manage_companies', views.manage_companies, name='manage_companies'),
    path('manage_alumnis', views.manage_alumnis, name='manage_alumnis'),

    path('manage_news', views.manage_news, name='manage_news'),
    path('delete_news/<int:id>', views.delete_news, name='delete_news'),
    path('edit_news/<int:id>', views.edit_news, name='edit_news'),

    path('moderate_reviews', views.moderate_reviews, name='moderate_reviews'),
    path('delete_review/<int:id>',views.delete_review, name='delete_review'),

    path('user_query', UserQuery.as_view(), name='user_query'),

]
