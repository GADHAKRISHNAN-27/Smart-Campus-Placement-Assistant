from django.shortcuts import render, redirect, get_object_or_404
from django.core.mail import send_mail
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.contrib import messages
from .models import *
from .forms import *
from django.conf import settings
from student.models import Feedback, JobApplication, CompanyReview


def register_company(request):
    if request.method == 'POST':
        form = CompanyRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            company = form.save(commit=False)
            company.user = request.user
            company.set_password(form.cleaned_data['password'])
            company.is_approved = False
            company.usertype = 1
            company.save()
            messages.success(request, f'Registration completed successfully. Please wait for an email confirming your registration status.', extra_tags='log')
            return redirect('/')
        else:
            print(form.is_valid)
    else:
        form = CompanyRegistrationForm()

    return render(request, 'register_company.html', {'form': form})

@login_required
def company_profile(request):
    user = get_object_or_404(Student, pk=request.user.pk)
    return render(request, 'company_profile.html', {'user': user})

@login_required
def company_edit_form(request):
    user = get_object_or_404(Student, pk=request.user.pk) 
    if request.method == 'POST':
        form = CompanyProfileForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, f'Profile updated successfully.', extra_tags='log')
            return redirect('/company_profile')
    else:
        form = CompanyProfileForm(instance=user)
    return render(request, 'company_edit_form.html', {'form': form})

@login_required
def company_dashboard(request):
    return render(request,'company_dashboard.html', {'user': request.user})

#--------------------------------------------------------------------------------------------------
@login_required
def job_posting_list(request):
    job_postings = JobPosting.objects.filter(company=request.user)
    return render(request, 'job_posting_list.html', {'job_postings': job_postings})

@login_required
def add_job_posting(request):
    if request.method == 'POST':
        form = JobPostingForm(request.POST)
        if form.is_valid():
            job_posting = form.save(commit=False)
            job_posting.company = request.user
            job_posting.save()
            messages.success(request,f'Successfully added the job post....After approval it will be posted in the Website...',extra_tags='log')
            return redirect('/job_posting_list')
    else:
        form = JobPostingForm()
    return render(request, 'add_job_posting.html', {'form': form})

@login_required
def edit_job_posting(request, pk):
    job_posting = get_object_or_404(JobPosting, pk=pk, company=request.user)
    if request.method == 'POST':
        form = JobPostingForm(request.POST, instance=job_posting)
        if form.is_valid():
            form.save()
            messages.success(request,f'Posted job is updated succesfully.',extra_tags='log')
            return redirect('/job_posting_list')
    else:
        form = JobPostingForm(instance=job_posting)
    return render(request, 'edit_job_posting.html', {'form': form})

@login_required
def delete_job_posting(request,pk):
    job_posting = get_object_or_404(JobPosting, pk=pk, company=request.user)
    job_posting.delete()
    messages.success(request,f'Job posting is deleted succesfully.',extra_tags='log')
    return redirect('/job_posting_list')



#-------------------------------------------------------------------------------------------------------------------


@login_required
def company_job_postings(request):
    if not request.user.is_authenticated:
        return redirect('/login')
    # Fetch all job postings for the logged-in company
    job_postings = JobPosting.objects.filter(company=request.user)
    return render(request, 'company_job_postings.html', {'job_postings': job_postings})


@login_required
def view_job_applications(request, job_posting_id):
    job_posting = get_object_or_404(JobPosting, id=job_posting_id, company=request.user)
    applications = JobApplication.objects.filter(job=job_posting)

    if request.method == 'POST':
        for application in applications:
            if f'select_{application.id}' in request.POST:
                application.status = 'selected'
                application.save()
                send_mail(
                    subject='Job Application Status',
                    message=f'Congratulations! You have been selected for the job.',
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=[application.student.email],
                    fail_silently=False,
                )
                messages.success(request,f'Application status is updated and mail send succesfully .',extra_tags='log')
            elif f'reject_{application.id}' in request.POST:
                application.status = 'rejected'
                application.save()

                send_mail(
                subject='Job Application Status',
                message=f'We regret to inform you that you have not been selected.',
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[application.student.email],
                fail_silently=False,
            )
                messages.success(request,f'Status changed, and mail send successfully.', extra_tags='log')
            
    
    return render(request, 'view_job_applications.html', {'job_posting': job_posting, 'applications': applications})


@login_required
def jobs_with_selected_candidates(request):
    if not request.user.is_authenticated:
        return redirect('login') 
    
    job_postings = JobPosting.objects.filter(company=request.user)


    jobs_with_selected = []
    for job in job_postings:
        selected_candidates = JobApplication.objects.filter(job=job, status='selected')
        
        print(f"Job '{job.title}' has {selected_candidates.count()} selected candidates")

        if selected_candidates.exists():
            jobs_with_selected.append(job)

    print(f"Jobs with selected candidates: {len(jobs_with_selected)}")

    return render(request, 'jobs_with_selected_candidates.html', {'jobs_with_selected': jobs_with_selected})

@login_required
def shortlist_view(request, job_posting_id):
    job_posting = get_object_or_404(JobPosting, id=job_posting_id, company=request.user)
    shortlisted_applications = JobApplication.objects.filter(job=job_posting, status='selected')

    # Fetch interviews for the shortlisted applications
    interviews = Interview.objects.filter(job_application__in=shortlisted_applications)
    interview_dict = {app.id: interviews.filter(job_application=app).first() for app in shortlisted_applications}

    return render(request, 'shortlist_view.html', {
        'job_posting': job_posting,
        'shortlisted_applications': shortlisted_applications,
        'interview_dict': interview_dict
    })

@login_required
def schedule_interview(request, job_application_id):
    job_application = get_object_or_404(JobApplication, pk=job_application_id)
    if request.method == 'POST':
        form = InterviewForm(request.POST)
        if form.is_valid():
            interview = form.save(commit=False)
            interview.job_application = job_application
            interview.status="scheduled"
            interview.save()

            
            # Send interview details to the student
            send_mail(
                subject='Interview Scheduled',
                message=f'Your interview has been scheduled on {interview.interview_date} at {interview.interview_time}.',
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[interview.job_application.email],
                fail_silently=False,
            )

            messages.success(request,f'Successfully scheduled the interview and the mail is send.', extra_tags='log')
            
            return redirect('shortlist_view', job_posting_id=job_application.job.id)
    else:
        form = InterviewForm()
    
    return render(request, 'schedule_interview.html', {'form': form, 'job_application': job_application})

@login_required
def interview_details(request, application_id):
    application = get_object_or_404(JobApplication, id=application_id)
    interview = get_object_or_404(Interview, job_application=application, status='scheduled')
    
    return render(request, 'interview_details.html', {'interview': interview})

#------------------------------------------------------------------------------------
@login_required
def view_company_reviews(request):
    if not request.user.is_authenticated:
        return redirect('login')

    company = request.user

    reviews = CompanyReview.objects.filter(company=company)

    return render(request, 'view_company_reviews.html', {'reviews': reviews, 'company': company})

@login_required
def delete_company_review(request, review_id):
    review = get_object_or_404(CompanyReview, pk=review_id, company=request.user)
    review.delete()
    messages.success(request, 'Review deleted successfully.', extra_tags='log')
    return redirect('view_company_reviews')

@login_required
def manage_job_offers(request):
    # Filter job applications based on job postings made by the logged-in company
    job_offers = JobApplication.objects.filter(
        job_title__in=JobPosting.objects.filter(company=request.user).values_list('title', flat=True)
    )
    return render(request, 'manage_job_offers.html', {'job_offers': job_offers})



@login_required
def provide_advertisement(request):
    if request.method == 'POST':
        form = AdvertisementForm(request.POST, request.FILES)
        if form.is_valid():
            advertisement = form.save(commit=False)
            advertisement.company = request.user
            advertisement.save()
            messages.success(request,f'Successfully added the advertisement...',extra_tags='log')
            return redirect('/advertisement_list')
    else:
        form = AdvertisementForm()
    return render(request, 'provide_advertisement.html', {'form': form})

@login_required
def advertisement_list(request):
    advertisements = Advertisement.objects.filter(company=request.user)
    return render(request, 'advertisement_list.html', {'advertisements': advertisements})

@login_required
def edit_advertisement(request, pk):
    advertisement = get_object_or_404(Advertisement, pk=pk, company=request.user)
    if request.method == 'POST':
        form = AdvertisementForm(request.POST, request.FILES, instance=advertisement)
        if form.is_valid():
            form.save()
            messages.success(request,f'Successfully updated the advertisement...',extra_tags='log')
            return redirect('/advertisement_list')
    else:
        form = AdvertisementForm(instance=advertisement)
    return render(request, 'edit_advertisement.html', {'form': form})

@login_required
def delete_advertisement(request, pk):
    advertisement = get_object_or_404(Advertisement, pk=pk, company=request.user)
    advertisement.delete()
    messages.success(request,f'Successfully deleted the advertisement...',extra_tags='log')
    return redirect('/advertisement_list')

@login_required
def view_feedbacks(request):
    feedbacks = Feedback.objects.filter(company_name=request.user.company_name)
    return render(request, 'view_feedbacks.html', {'feedbacks': feedbacks})

@login_required
def delete_feedback(request,pk):
    feedback = get_object_or_404(Feedback, pk=pk)
    feedback.delete()
    messages.success(request,f'Successfully deleted the feedback...',extra_tags='log')
    return redirect('/view_feedbacks')

@login_required
def interview_attending(request):
    company = request.user 
    
    # Filter interviews with status 'scheduled' and for the company's job postings
    scheduled_interviews = Interview.objects.filter(
        job_application__job__company=company,
        status='scheduled' 
    )
    context = {
        'scheduled_interviews': scheduled_interviews
    }
    return render(request, 'interview_attending.html', context)