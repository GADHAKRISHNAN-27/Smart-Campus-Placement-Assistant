from django import forms
from django.core.validators import URLValidator, EmailValidator
from django.core.exceptions import ValidationError
from .models import *
from student.models import Student
from django.utils import timezone
import re
from django.core.validators import validate_email


class CompanyRegistrationForm(forms.ModelForm):
    confirm_password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control bg-light text-dark', 'placeholder': 'Confirm Password *'})
    )
    logo = forms.ImageField(
        required=False,
        widget=forms.ClearableFileInput(attrs={'class': 'form-control-file bg-light'})
    )

    class Meta:
        model = Student
        fields = ['company_name', 'website', 'description', 'logo', 'address', 'email', 'username', 'password', 'confirm_password']
        widgets = {
            'company_name': forms.TextInput(attrs={'class': 'form-control  bg-light text-dark', 'placeholder': 'Company Name *'}),
            'website': forms.URLInput(attrs={'class': 'form-control  bg-light text-dark', 'placeholder': 'Website *'}),
            'description': forms.Textarea(attrs={'class': 'form-control  bg-light text-dark', 'placeholder': 'Description *'}),
            'address': forms.Textarea(attrs={'class': 'form-control  bg-light text-dark', 'placeholder': 'Address *'}),
            'email': forms.EmailInput(attrs={'class': 'form-control  bg-light text-dark', 'placeholder': 'Email *'}),
            'username': forms.TextInput(attrs={'class': 'form-control  bg-light text-dark', 'placeholder': 'Name *'}),
            'password': forms.PasswordInput(attrs={'class': 'form-control bg-light text-dark', 'placeholder': 'Password *'}),
        }

    # Required Field Validation
    def clean_company_name(self):
        company_name = self.cleaned_data.get('company_name')
        if not company_name:
            raise ValidationError('This field is required.')
        if any(char.isdigit() for char in company_name):
            raise ValidationError('Company name cannot contain numbers.')
        return company_name

    def clean_website(self):
        website = self.cleaned_data.get('website')
        validator = URLValidator()
        try:
            validator(website)
        except ValidationError:
            raise forms.ValidationError("Please enter a valid website URL.")
        return website

    # Email Validation
    
    def clean_email(self):
        cleaned_email = self.cleaned_data.get('email')
        
        # Validate the structure of the email
        try:
            validate_email(cleaned_email)
        except ValidationError:
            raise forms.ValidationError("Invalid email format.")
        
        if '@' not in cleaned_email:
            raise ValidationError('Please enter a valid email address.')
        
        # Check if the email is already registered
        if Student.objects.filter(email=cleaned_email).exists():
            raise forms.ValidationError("This email is already registered.")
        
        return cleaned_email

    # Password Strength Validation
    def clean_password(self):
        password = self.cleaned_data.get('password')
        if len(password) < 8 or len(password) > 12:
            raise forms.ValidationError("Password must be between 8 and 12 characters long.")
        if not re.search(r'[A-Z]', password):
            raise forms.ValidationError("Password must contain at least one uppercase letter.")
        if not re.search(r'[a-z]', password):
            raise forms.ValidationError("Password must contain at least one lowercase letter.")
        if not re.search(r'[0-9]', password):
            raise forms.ValidationError("Password must contain at least one digit.")
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            raise forms.ValidationError("Password must contain at least one special character.")
        return password

    # Confirm Password Validation
    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")
        if password and confirm_password and password != confirm_password:
            raise forms.ValidationError("Passwords do not match.")
        return cleaned_data
    

class CompanyProfileForm(forms.ModelForm):
    logo = forms.ImageField(
        required=False,
        widget=forms.ClearableFileInput(attrs={'class': 'form-control-file'})
    )

    class Meta:
        model = Student
        fields = ['company_name', 'website', 'description', 'logo', 'address']
        widgets = {
            'company_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Company Name *'}),
            'website': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'Website URL *'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Description *'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Address of company *'}),
        }

    # Pattern/Regex Validation for Company Name (No numbers allowed)
    def clean_company_name(self):
        company_name = self.cleaned_data.get('company_name')
        if any(char.isdigit() for char in company_name):
            raise forms.ValidationError('Company name cannot contain numbers.')
        return company_name

    def clean_website(self):
        website = self.cleaned_data.get('website')
        validator = URLValidator()
        try:
            validator(website)
        except ValidationError:
            raise forms.ValidationError("Please enter a valid website URL.")
        return website


class JobPostingForm(forms.ModelForm):
    class Meta:
        model = JobPosting
        fields = ['title', 'description', 'location', 'salary', 'application_deadline']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Job Title *'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Job Description *'}),
            'location': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Location *'}),
            'salary': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter the salary range *'}),
            'application_deadline': forms.DateInput(attrs={'type': 'date', 'class': 'form-control', 'placeholder': 'Application Deadline *'}),
        }

    

    # Date Validation (Application Deadline cannot be in the past)
    def clean_application_deadline(self):
        application_deadline = self.cleaned_data.get('application_deadline')
        if application_deadline and application_deadline < timezone.now().date():
            raise forms.ValidationError('The application deadline cannot be in the past.')
        return application_deadline



class AdvertisementForm(forms.ModelForm):
    class Meta:
        model = Advertisement
        fields = ['title', 'description', 'image', 'start_date', 'end_date', 'is_active']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Advertisement Title *'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Advertisement Description *'}),
            'image': forms.FileInput(attrs={'class': 'form-control-file', 'placeholder': 'Image *'}),
            'start_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date', 'placeholder': 'Starting Date *'}),
            'end_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date', 'placeholder': 'Ending Date *'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }

    # File Upload Validation (Accept only image files, max size 5 MB)
    def clean_image(self):
        image = self.cleaned_data.get('image')
        if image:
            if not image.content_type.startswith('image'):
                raise forms.ValidationError('Only image files are allowed.')
            if image.size > 5 * 1024 * 1024:
                raise forms.ValidationError('The image file size cannot exceed 5 MB.')
        return image

    # Date Validation (Start date must be before end date)
    def clean(self):
        cleaned_data = super().clean()
        start_date = cleaned_data.get('start_date')
        end_date = cleaned_data.get('end_date')
        if start_date and end_date and start_date > end_date:
            raise forms.ValidationError('Start date cannot be after the end date.')
        return cleaned_data



class InterviewForm(forms.ModelForm):
    class Meta:
        model = Interview
        fields = ['interview_date', 'interview_time', 'location', 'notes', 'status']
        widgets = {
            'interview_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date', 'placeholder': 'Interview Date *'}),
            'interview_time': forms.TimeInput(attrs={'class': 'form-control', 'type': 'time', 'placeholder': 'Interview Time *'}),
            'location': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Location *'}),
            'notes': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Job Application Notes'}),
            'status': forms.Select(attrs={'class': 'form-control'}),
        }

    # Required Field Validation
    def clean_location(self):
        location = self.cleaned_data.get('location')
        if not location:
            raise forms.ValidationError('This field is required.')
        return location

    # Date Validation (Interview date cannot be in the past)
    def clean_interview_date(self):
        interview_date = self.cleaned_data.get('interview_date')
        if interview_date and interview_date < timezone.now().date():
            raise forms.ValidationError('The interview date cannot be in the past.')
        return interview_date
