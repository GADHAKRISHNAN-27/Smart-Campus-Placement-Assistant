from django.urls import path
from . import views

urlpatterns = [
    path('register_company', views.register_company, name='register_company'),
    path('company_profile',views.company_profile, name='company_profile'),
    path('company_edit_form', views.company_edit_form,name='company_edit_form'),
    path('company_dashboard',views.company_dashboard, name='company_dashboard'),

    path('company_job_postings', views.company_job_postings, name='company_job_postings'),
    path('view_job_applications/<int:job_posting_id>', views.view_job_applications, name='view_job_applications'),
    path('schedule_interview/<int:job_application_id>', views.schedule_interview, name='schedule_interview'),

    path('jobs_with_selected_candidates', views.jobs_with_selected_candidates, name='jobs_with_selected_candidates'),
    path('shortlist/<int:job_posting_id>/', views.shortlist_view, name='shortlist_view'),
    path('interview_details/<int:application_id>', views.interview_details, name='interview_details'),
    path('interview_attending',views.interview_attending,name='interview_attending'),
   
    path('view_company_reviews', views.view_company_reviews, name='view_company_reviews'),
    path('delete_company_review/<int:review_id>', views.delete_company_review, name='delete_company_review'),

    path('job_posting_list', views.job_posting_list, name='job_posting_list'),
    path('add_job_posting', views.add_job_posting, name='add_job_posting'),
    path('edit_job_posting/<int:pk>', views.edit_job_posting, name='edit_job_posting'),
    path('delete_job_posting/<int:pk>', views.delete_job_posting, name='delete_job_posting'),

    path('manage_job_offers', views.manage_job_offers, name='manage_job_offers'),
   
    path('advertisement_list', views.advertisement_list, name='advertisement_list'),
    path('provide_advertisement', views.provide_advertisement, name='provide_advertisement'),
    path('edit_advertisement/<int:pk>', views.edit_advertisement, name='edit_advertisement'),
    path('delete_advertisement/<int:pk>', views.delete_advertisement, name='delete_advertisement'),

    path('view_feedbacks', views.view_feedbacks, name='view_feedbacks'),
    path('delete_feedback/<int:pk>', views.delete_feedback, name='delete_feedback'),
]
