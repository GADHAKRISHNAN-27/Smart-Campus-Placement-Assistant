from django.db import models
from django.core.exceptions import ValidationError
from django.utils import timezone

class JobPosting(models.Model):
    company = models.ForeignKey('student.Student', on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    description = models.TextField()
    location = models.CharField(max_length=255)
    salary = models.CharField(max_length=50, null=True, blank=True)
    date_posted = models.DateField(auto_now_add=True)
    application_deadline = models.DateField()
    is_approved = models.CharField( max_length=10,default=False)

    def __str__(self):
        return self.title
    
    def clean(self):
        super().clean()
        if self.application_deadline and self.application_deadline < timezone.now().date():
            raise ValidationError('The application deadline cannot be in the past.')



class Advertisement(models.Model):
    company = models.ForeignKey('student.Student', on_delete=models.CASCADE, related_name='advertisements')
    title = models.CharField(max_length=255)
    description = models.TextField()
    image = models.ImageField(upload_to='advertisements/', blank=True, null=True)
    start_date = models.DateField()
    end_date = models.DateField()
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.title} by {self.company.company_name}"
    
    def clean(self):
        super().clean()
        if self.start_date and self.start_date < timezone.now().date():
            raise ValidationError('The Ad starting cannot be in the past.')


class Interview(models.Model):
    job_application = models.ForeignKey('student.JobApplication', on_delete=models.CASCADE, related_name='schedule_interview')
    interview_date = models.DateField()
    interview_time = models.TimeField()
    location = models.CharField(max_length=255)
    notes = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=50, choices=[('scheduled', 'Scheduled'), ('completed', 'Completed')], default='scheduled')

    def __str__(self):
        return f"Interview for {self.job_application.job_title} with {self.job_application.name}"
