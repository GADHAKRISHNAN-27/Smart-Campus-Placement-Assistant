from django.utils import timezone
from django.db import models
from django.contrib.auth.models import AbstractUser


class Student(AbstractUser):
    username = models.CharField(max_length=150, unique=True)
    usertype = models.IntegerField(default=0)
    phone = models.IntegerField(default=0)
    course = models.CharField(max_length=200, default='', null=True)
    specialization = models.CharField(max_length=200, default='', null=True)
    image = models.ImageField(null=True, upload_to='uploads/')
    company_name = models.CharField(max_length=255,default='',null=True)
    website = models.URLField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    logo = models.ImageField(upload_to='company_logos/', blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    graduation_year = models.IntegerField(null=True, blank=True)
    job_title = models.CharField(max_length=255, null=True, blank=True)
    company = models.CharField(max_length=255, null=True, blank=True)
    is_approved = models.CharField(max_length=10,default=True)

     
    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email']  

    def __str__(self):
         return f"{self.username} - {self.company_name}"
    

class JobApplication(models.Model):
    student = models.ForeignKey(Student,on_delete=models.CASCADE, related_name='job_applications',default='')
    name = models.CharField(max_length=255)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    job_title = models.CharField(max_length=255)
    course = models.CharField(max_length=20)
    specialization = models.CharField(max_length=20)
    resume = models.FileField(upload_to='resumes/')
    cover_letter = models.TextField()
    application_date = models.DateField(auto_now_add=True)
    status = models.CharField(max_length=50, choices=[('applied', 'Applied'), ('shortlisted', 'Shortlisted'), ('rejected', 'Rejected'),('selected','Selected')], default='applied')
    job = models.ForeignKey('company.JobPosting', on_delete=models.CASCADE, default='')
    applied_on = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.job_title}"

class CompanyReview(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='company_reviews_given')
    company = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='reviews_from_students')
    rating = models.DecimalField(max_digits=3, decimal_places=1) 
    review = models.TextField()
    review_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.username} - {self.student.company_name} - {self.rating} - {self.review}"
  

class UserQueries(models.Model):
    name = models.CharField(max_length=50,default='')
    email = models.EmailField()
    phone = models.IntegerField(default=0)
    subject = models.CharField(max_length=50)
    message = models.TextField(max_length=500)
    created_at = models.DateTimeField(default=timezone.now)


class Feedback(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    company_name = models.CharField(max_length=255)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.student.username} feedback for {self.company_name}'
