from django import forms
from administrator.models import Course, Specialization
from .models import *
from django.contrib.auth.forms import PasswordChangeForm
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
import re


class RegisterForm(forms.ModelForm):
    confirm_password = forms.CharField(
        required=True,
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Confirm Password'})
    )
    password = forms.CharField(
        required=True,
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password'})
    )
    phone = forms.CharField(
        required=True,
        max_length=10,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'id': 'id_contact', 'placeholder': 'Phone'})
    )
    image = forms.ImageField(
        required=False,
        widget=forms.ClearableFileInput(attrs={'class': 'form-control-file bg-light'})
    )
    course = forms.ModelChoiceField(
        queryset=Course.objects.all(),
        required=True,
        widget=forms.Select(attrs={'class': 'form-control ', 'placeholder': 'Select course'}),
        empty_label='Select course'
    )
    specialization = forms.ModelChoiceField(
        queryset=Specialization.objects.all(),
        required=True,
        widget=forms.Select(attrs={'class': 'form-control', 'placeholder': 'Select specialization'}),
        empty_label='Select specialization'
    )

    class Meta:
        model = Student
        fields = ['username', 'email', 'phone', 'course', 'specialization', 'image', 'password', 'confirm_password']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Your Name'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Email'}),
        }
        help_texts = {'username': None, 'email': None, 'phone': None, 'image': None}

    def clean_password(self):
        password = self.cleaned_data.get('password')
        if len(password) < 8 or len(password) > 12:
            raise forms.ValidationError("Password must be between 8 and 12 characters long.")
        if not re.search(r'[A-Z]', password):
            raise forms.ValidationError("Password must contain at least one uppercase letter.")
        if not re.search(r'[a-z]', password):
            raise forms.ValidationError("Password must contain at least one lowercase letter.")
        if not re.search(r'[0-9]', password):
            raise forms.ValidationError("Password must contain at least one digit.")
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            raise forms.ValidationError("Password must contain at least one special character.")
        return password

    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        
        # Check if the phone contains only digits
        if not phone.isdigit():
            raise forms.ValidationError("Phone number must contain only digits.")
        
        # Check the length of the phone number (must be exactly 10 digits)
        if len(phone) != 10:
            raise forms.ValidationError("Phone number must be exactly 10 digits.")
        
        # Check if the phone number starts with 6, 7, 8, or 9
        if phone[0] not in ['6', '7', '8', '9']:
            raise forms.ValidationError("Phone number must start with 6, 7, 8, or 9.")
        
        return phone

    def clean_email(self):
        cleaned_email = self.cleaned_data.get('email')
        
        # Validate the structure of the email
        try:
            validate_email(cleaned_email)
        except ValidationError:
            raise forms.ValidationError("Invalid email format.")
        
        if '@' not in cleaned_email:
            raise ValidationError('Please enter a valid email address.')
        
        # Check if the email is already registered
        if Student.objects.filter(email=cleaned_email).exists():
            raise forms.ValidationError("This email is already registered.")
        
        return cleaned_email

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        if password and confirm_password and password != confirm_password:
            raise forms.ValidationError("Passwords do not match. Please enter again.")
        
        return cleaned_data


class ProfileForm(forms.ModelForm):
    course = forms.ModelChoiceField(
        queryset=Course.objects.all(),
        required=True,
        widget=forms.Select(attrs={'class': 'form-control', 'placeholder': 'Select course'}),
        empty_label='Select course'
    )
    specialization = forms.ModelChoiceField(
        queryset=Specialization.objects.all(),
        required=True,
        widget=forms.Select(attrs={'class': 'form-control', 'placeholder': 'Select specialization'}),
        empty_label='Select specialization'
    )

    class Meta:
        model = Student
        fields = ['username', 'email', 'phone', 'course', 'specialization', 'image']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Username'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Email'}),
            'phone': forms.NumberInput(attrs={'class': 'form-control','id': 'id_contact', 'placeholder': 'Phone'}),
        }
        help_texts = {'username': None, 'email': None, 'phone': None}

    def clean_email(self):
        cleaned_email = self.cleaned_data.get('email')
        
        # Validate the structure of the email
        try:
            validate_email(cleaned_email)
        except ValidationError:
            raise forms.ValidationError("Invalid email format.")
        
        if '@' not in cleaned_email:
            raise ValidationError('Please enter a valid email address.')
        
       
        
        return cleaned_email


class LoginForm(forms.ModelForm):

    class Meta:
        model = Student
        fields = ['username', 'password']

        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control bg-light text-dark'}),
            "password": forms.PasswordInput(attrs={"class":"form-control bg-light text-dark pswd"}),
           
           }
        

class ForgotPasswordForm(forms.Form):
    username = forms.CharField(
        max_length=150,
        required=True,  # Set required to False to bypass required validation
        widget=forms.TextInput(attrs={'class': 'form-group'}),
    )

    def clean(self):
        cleaned_data = super().clean()
        # Optionally, you can add custom cleaning logic here
        return cleaned_data


class PasswordChangeForm(PasswordChangeForm):
    old_password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control bg-light', 'placeholder': 'Old Password'}),
        label="Old Password"
    )
    new_password1 = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control bg-light', 'placeholder': 'New Password'}),
        label="New Password"
    )
    new_password2 = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control bg-light', 'placeholder': 'Confirm New Password'}),
        label="Confirm New Password"
    )

    

    @staticmethod
    def validate_password(password):
        if len(password) < 8 or len(password) > 12:
            raise forms.ValidationError("Password must be between 8 and 12 characters long.")
        if not re.search(r'[A-Z]', password):
            raise forms.ValidationError("Password must contain at least one uppercase letter.")
        if not re.search(r'[a-z]', password):
            raise forms.ValidationError("Password must contain at least one lowercase letter.")
        if not re.search(r'[0-9]', password):
            raise forms.ValidationError("Password must contain at least one digit.")
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            raise forms.ValidationError("Password must contain at least one special character.")
        return password
        
    def clean_new_password1(self):
        new_password1 = self.cleaned_data.get('new_password1')
        self.validate_password(new_password1)
        return new_password1
       
    def clean(self):
        cleaned_data = super().clean()
        old_password = cleaned_data.get("old_password")
        new_password1 = cleaned_data.get("new_password1")

        # Ensure the new password is different from the old password
        if old_password and new_password1 and old_password == new_password1:
            self.add_error('new_password1', "The new password must be different from the old password.")
        
        return cleaned_data
    

class JobApplicationForm(forms.ModelForm):
    course = forms.ModelChoiceField(
        queryset=Course.objects.all(),
        required=True,
        widget=forms.Select(attrs={'class': 'form-control bg-light text-dark', 'placeholder': 'Select course'}),
        empty_label='Select course'
    )
    specialization = forms.ModelChoiceField(
        queryset=Specialization.objects.all(),
        required=True,
        widget=forms.Select(attrs={'class': 'form-control bg-light text-dark', 'placeholder': 'Select specialization'}),
        empty_label='Select specialization'
    )

    class Meta:
        model = JobApplication
        fields = ['name', 'email', 'phone', 'job_title', 'course', 'specialization', 'resume', 'cover_letter']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control bg-light text-dark', 'placeholder': 'Enter your name'}),
            'email': forms.EmailInput(attrs={'class': 'form-control bg-light text-dark', 'placeholder': 'Enter your email'}),
            'phone': forms.NumberInput(attrs={'class': 'form-control bg-light text-dark', 'id': 'id_contact', 'placeholder': 'Enter your phone number'}),
            'job_title': forms.TextInput(attrs={'class': 'form-control bg-light text-dark'}),
            'resume': forms.FileInput(attrs={'class': 'form-control bg-light text-dark'}),
            'cover_letter': forms.Textarea(attrs={'class': 'form-control bg-light text-dark', 'placeholder': 'Enter your cover letter'}),
        }

    def clean_resume(self):
        resume = self.cleaned_data.get('resume')
        if resume.size > 5 * 1024 * 1024:
            raise forms.ValidationError("Resume file size should not exceed 5MB.")
        return resume
    
    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        
        # Check if the phone contains only digits
        if not phone.isdigit():
            raise forms.ValidationError("Phone number must contain only digits.")
        
        # Check the length of the phone number (must be exactly 10 digits)
        if len(phone) != 10:
            raise forms.ValidationError("Phone number must be exactly 10 digits.")
        
        # Check if the phone number starts with 6, 7, 8, or 9
        if phone[0] not in ['6', '7', '8', '9']:
            raise forms.ValidationError("Phone number must start with 6, 7, 8, or 9.")
        
        return phone

    def clean_email(self):
        cleaned_email = self.cleaned_data.get('email')
        # Validate the structure of the email
        try:
            validate_email(cleaned_email)
        except ValidationError:
            raise forms.ValidationError("Invalid email format.")
        if '@' not in cleaned_email:
            raise ValidationError('Please enter a valid email address.')
        return cleaned_email


    
class CompanyReviewForm(forms.ModelForm):
    class Meta:
        model = CompanyReview
        fields = ['rating', 'review']
        widgets = {
            'rating': forms.NumberInput(attrs={
                'class': 'form-control', 
                'type': 'range',
                'min': '0.0',
                'max': '5.0',
                'step': '0.1', 
                'oninput': 'this.nextElementSibling.value = this.value'
            }),
            'review': forms.Textarea(attrs={'class': 'form-control text-dark bg-white', 'placeholder': 'Enter your review here'}),
        }
        labels = {
            'rating': 'Rating',
            'review': 'Review',
        }

                                                                                                                                                                                    
class FeedbackForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Enter your feedback...'}),
        }                                                                                           
                                                                                                     
                                                                                                    