from django.contrib import messages
from django.http import HttpResponse
from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth.hashers import make_password
from django.core.mail import send_mail
from django.conf import settings
from django.contrib import auth
from django.contrib.auth import authenticate, login, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from administrator.models import *
from company.models import *
from . models import *
from .forms import *
import secrets
import string
from django.utils.timezone import now
from administrator.forms import *
from alumni.forms import *
from alumni.models import *
from  company.forms import *
from django.db.models import Q
from django.db.models import Avg, Count

def index(request):
    advertisements = Advertisement.objects.filter(is_active=True)
    companies_with_avg_rating = CompanyReview.objects.values('company__id', 'company__company_name', 'company__logo').annotate(avg_rating=Avg('rating')).order_by('-avg_rating')[:10]
    for index, company in enumerate(companies_with_avg_rating, start=1):
        company['ranking'] = index
    return render(request, 'index.html', {'advertisements': advertisements, 'companies': companies_with_avg_rating})

def doReg(request):
    return render(request,'home.html')

def about(request):
    return render(request, 'about.html')

def contact(request):
    if request.method == 'POST':
        name = request.POST.get('w3lName')
        email = request.POST.get('w3lSender')
        phone = request.POST.get('w3lPhone')
        subject = request.POST.get('w3lSubject')
        message = request.POST.get('w3lMessage')

        # Validate and process the form data
        if name and email and phone and subject and message:
            try:
                # Create and save a new UserQueries object
                user_query = UserQueries(
                    name=name,
                    email=email,
                    phone=int(phone), 
                    subject=subject,
                    message=message
                )
                user_query.save()
        
                messages.success(request, 'Your message has been sent successfully!',extra_tags='con')
                return redirect('/contact') 
            except Exception as e:
                messages.error(request, f'Error saving your message: {e}')
        else:
            messages.error(request, 'Please fill in all required fields.', extra_tags='log')

    return render(request, 'contact.html')



def doLogin(request):
    form = LoginForm()
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        
        user = authenticate(request, username=username, password=password)
        if user is None:
            # Authentication failed
            messages.error(request, f'Invalid username or password.', extra_tags='log')
            return render(request, 'login.html', {'form': form, 'k': True})
        
        try:
            data = Student.objects.get(username=user.username)
            print(f'User: {data.username}, Approved: {data.is_approved}')
            if data.is_approved == "False":
                # User is not approved
                messages.error(request, f'Your account has not been approved yet.', extra_tags='log')
                return render(request, 'login.html', {'form': form, 'k': True})

            # Log the user in
            login(request, user)
            request.session['ut'] = data.usertype
            request.session['uid'] = data.id
            
            # Success message
            messages.success(request, f'Login Successful! Welcome {data.username}', extra_tags='log')
            
            # Redirect based on usertype
            if data.usertype == 0:
                return redirect('/admin_dashboard')
            elif data.usertype == 1:
                return redirect('/company_dashboard')
            elif data.usertype == 2:
                return redirect('/alumni_dashboard')
            elif data.usertype == 3:
                return redirect('/student_dashboard')
                
        except Student.DoesNotExist:
            # User data not found
            messages.error(request, f'User data not found.', extra_tags='log')
            return redirect('/login')

    return render(request, 'login.html', {'form': form}) 

@login_required
def logout(request):
    auth.logout(request)
    return redirect('/') 

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST, request.FILES)
        if form.is_valid():
            emails = form.cleaned_data["email"]
            if Student.objects.filter(email=emails).exists():
                login_form = LoginForm()  
                return render(request, 'login.html', {'form': login_form, 'z': True})
            else:
                try:
                    user = form.save(commit=False)
                    user.usertype = 3
                    user.is_approved = True
                    user.password = make_password(form.cleaned_data['password'])
                    user.save()
                    messages.success(request, f'Your registration has been successful! You can login now.',extra_tags='reg')
                    return redirect('/login')
                except Exception as e:
                    form.add_error(None, f'An error occurred while saving the form: {e}')
        return render(request, 'register.html', {'form': form})
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})

def forgotpswd(request):
    return render(request, 'forgotpswd.html', {'user': request.user})

@login_required
def profile(request):
    user = request.user
    if not user.is_authenticated:
        return redirect('/login')
    
    user_type = user.usertype
    context = {'user': user}

    if user_type == 0:  # Admin
        # Fetch admin-specific data if needed
        return render(request, 'admin_profile.html', context)
    elif user_type == 1:  # Company
        # Fetch company-specific data if needed
        return render(request, 'company_profile.html', context)
    elif user_type == 2:  # Alumni
        # Fetch alumni-specific data if needed
        return render(request, 'alumni_profile.html', context)
    elif user_type == 3:  # Student
        # Fetch student-specific data if needed
        return render(request, 'profile.html', context)
    else:
        # Handle unknown user type
        return redirect('/index')

def generate_random_password(length=6):
    characters = string.ascii_letters + string.digits
    password = ''.join(secrets.choice(characters) for _ in range(length))
    return password

def reset_password(request):
    if request.method == "POST":

                user = Student.objects.get(username=request.POST['username'])
                print("USERSS",user)
                new_password = generate_random_password()
                user.password = make_password(new_password)
                print('Nesw Passworddddddddd',new_password)
                user.save()
                subject = 'password'
                message = "your password is " + str(new_password)
                email_from = settings.EMAIL_HOST_USER
                recepient_list = [user.email]  
                send_mail(subject,message,email_from,recepient_list)
                messages.success(request, f'New Password is send to your registered email. Use it for login and change your password in your profile section. ', extra_tags='log')
               
    else:
        return render(request,"forgotpswd.html")
    return redirect('/login')

@login_required
def edit_profile(request):
    if not request.user.is_authenticated:
        return redirect('/login')

    user = request.user
    user_type = user.usertype

    if request.method == 'POST':
        if user_type == 0:  # Admin
            form = AdminProfileForm(request.POST, request.FILES, instance=user)
        elif user_type == 1:  # Company
            form = CompanyProfileForm(request.POST, request.FILES, instance=user)
        elif user_type == 2:  # Alumni
            form = AlumniProfileForm(request.POST, request.FILES, instance=user)
        elif user_type == 3:  # Student
            form = ProfileForm(request.POST, request.FILES, instance=user)
        else:
            return redirect('/index')

        if form.is_valid():
            email = form.cleaned_data['email']
            # Check if the email is already in use by another user
            if Student.objects.filter(email=email).exclude(id=user.id).exists():
                form.add_error('email', 'Email already exists')
            else:
                try:
                    user = form.save(commit=False)
                    if form.cleaned_data.get('password'):
                        user.password = make_password(form.cleaned_data['password'])
                    user.save()

                    # Update the session with the new user data
                    update_session_auth_hash(request, user)

                    messages.success(request, 'Profile updated successfully.',extra_tags='edit')
                    return redirect('/profile')
                except Exception as e:
                    form.add_error(None, f'An error occurred while updating the profile: {e}')
        else:
            messages.error(request, 'Please correct the errors below.', extra_tags='log')
    else:
        if user_type == 0:  # Admin
            form = AdminProfileForm(instance=user)
        elif user_type == 1:  # Company
            form = CompanyProfileForm(instance=user)
        elif user_type == 2:  # Alumni
            form = AlumniProfileForm(instance=user)
        elif user_type == 3:  # Student
            form = ProfileForm(instance=user)
        else:
            return redirect('/profile')

    return render(request, 'update_form.html', {'form': form})

@login_required
def change_password(request):
    if request.method == 'POST':
        print("POST request received.")
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            print("Form is valid.")
            try:
                user = form.save()
                update_session_auth_hash(request, user)  # Keep the user logged in after password change
                messages.success(request, 'Your password has been changed successfully.',extra_tags='pwd')
                return redirect('/login')
            except Exception as e:
                print(f"Error saving form: {e}")
                messages.error(request, 'An error occurred. Please try again.',extra_tags='pwd')
        else:
            # Debugging: print form errors
            print("Form is not valid.")
            print(f"Form errors: {form.errors}")
            messages.error(request, 'Please correct the error below.',extra_tags='pwd')
    else:
        print("GET request received.")
        form = PasswordChangeForm(user=request.user)
    
    return render(request, 'password_change_form.html', {'form': form})

@login_required
def student_dashboard(request):
    # Fetch active advertisements
    advertisements = Advertisement.objects.filter(is_active=True)
    

    # Render the template with all the data
    return render(request, 'student_dashboard.html', {'advertisements': advertisements})

@login_required
def companies(request):
    query = request.GET.get('search', '')
    
    # Get distinct job titles for autocomplete
    job_list = JobPosting.objects.values_list('title', flat=True).distinct()

    # Filter companies based on the search query
    if query:
        companies = Student.objects.filter(
            Q(jobposting__title__icontains=query) |  # Search in job titles (case-insensitive)
            Q(company_name__icontains=query)  # Search in company names (case-insensitive)
        ).distinct()
    else:
        companies = Student.objects.filter(usertype=1,is_approved=True)

    # Annotate each company with average rating and review count
    companies = companies.annotate(
        avg_rating=Avg('reviews_from_students__rating'),
        review_count=Count('reviews_from_students')
    ).order_by('-avg_rating')  # Order by the highest average rating

    return render(request, 'companies.html', {
        'companies': companies,
        'job_list': job_list,
        'query': query
    })




@login_required
def job_list(request, company_id):
    company = get_object_or_404(Student, id=company_id)
    jobs = JobPosting.objects.filter(company=company)

    return render(request, 'job_list.html', {'company': company, 'jobs': jobs})



@login_required
def apply_job(request, job_id):
    job = get_object_or_404(JobPosting, id=job_id)
    form = JobApplicationForm(request.POST, request.FILES)
    
    if request.method == 'POST':
        if form.is_valid():
            job_application = JobApplication(
                student=request.user,
                name=form.cleaned_data['name'],
                email=form.cleaned_data['email'],
                phone=form.cleaned_data['phone'],
                job_title=form.cleaned_data['job_title'],
                course=form.cleaned_data['course'],
                specialization=form.cleaned_data['specialization'],
                resume=form.cleaned_data['resume'],
                cover_letter=form.cleaned_data['cover_letter'],
                job=job  
            )
            job_application.save()

            # Send a confirmation email
            send_mail(
                subject='Job Application Received',
                message=f'Thank you for applying to {job.title}. We have received your application.',
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[form.cleaned_data['email']],
                fail_silently=False,
            )

            messages.success(request, 'Your application has been submitted successfully!', extra_tags='log')
            return redirect('/companies') 

    else:
        form = JobApplicationForm(initial={'job_title': job.title})

    return render(request, 'apply_job.html', {'form': form, 'job': job})




@login_required
def company_view(request, id):
    company = get_object_or_404(Student, id=id)
    reviews = CompanyReview.objects.filter(company=company)
    
    if request.method == 'POST':
        form = CompanyReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.company = company
            review.student = request.user
            review.save()
            messages.success(request, 'Thank you for your review!', extra_tags='log')
            return redirect('company_view', id=company.id)
    else:
        form = CompanyReviewForm()

    context = {
        'company': company,
        'reviews': reviews,
        'form': form,
    }
    return render(request, 'company_view.html', context)


@login_required
def track_applications(request):
    applications = JobApplication.objects.filter(student=request.user)
    return render(request, 'track_application.html', {'applications':applications})


@login_required
def track_application_details(request, application_id):
    application = get_object_or_404(JobApplication, id=application_id)
    interviews = Interview.objects.filter(job_application=application)
    current_time = timezone.now().date()

    context = {
        'application': application,
        'interviews': interviews,
        'current_time': current_time  # Pass current time to the template
    }
    return render(request, 'track_application_details.html', context)


@login_required
def confirm_interview(request, interview_id):
    interview = get_object_or_404(Interview, id=interview_id)
    
    if request.method == 'POST':
        current_time = timezone.now().date()

        # Check if the interview date is in the past
        if interview.interview_date <= current_time:
            interview.status = 'completed'
        else:
            interview.status = 'scheduled'
        
        interview.save()
        
        # Update the related job application's status to 'shortlisted'
        application = interview.job_application
        application.status = 'shortlisted'
        application.save()



        # Send confirmation email
        send_mail(
            'Interview Confirmation',
            f'Your interview for the job {interview.job_application.job_title} has been confirmed.',
            'from@example.com',
            [interview.job_application.student.email],
            fail_silently=False,
        )

        messages.success(request,f'Successfully confirmed the interview. you can attend the interview on time.', extra_tags='log')
        
        return redirect('/track_interviews')
    
    return render(request, 'confirm_interview.html', {'interview': interview})

@login_required
def cancel_interview(request,pk):
    interview = get_object_or_404(Interview, id=pk)
    interview.delete()
    messages.success(request,f"Successfully canceled the interview. You no longer can attend the interview.",extra_tags='log')
    return redirect('/track_interviews')




@login_required
def track_interviews(request):
    interviews = Interview.objects.filter(job_application_id__student=request.user)
    return render(request, 'track_interviews.html', {'interviews': interviews})

@login_required
def view_placement_stats(request):
    job_applications_count = JobApplication.objects.filter(applicants=request.user).count()
    interviews_count = Interview.objects.filter(student=request.user).count()
    successful_placements = Interview.objects.filter(student=request.user, status='Placed').count()
    
  # Aggregate job applications by type (if you have job types in your model)
    job_types = JobPosting.objects.filter(applicants=request.user).values('type').annotate(total=models.Count('id'))
    
    return render(request, 'placement_stats.html', {'job_applications_count': job_applications_count,
        'interviews_count': interviews_count,
        'successful_placements': successful_placements,
        'job_types': job_types})

@login_required
def story_detail(request):
    stories = SuccessStory.objects.all()
    return render(request, 'story_detail.html', {'stories': stories})

@login_required
def advice_detail(request):
    advices = CareerAdvice.objects.all()
    return render(request, 'advice_detail.html', {'advices': advices})

@login_required
def job_detail(request):
    jobs = JobOpening.objects.all()
    return render(request, 'job_detail.html', {'jobs': jobs})

@login_required
def testimonial_detail(request):
    testimonials = PlacementTestimonial.objects.all()
    return render(request, 'testimonial_detail.html', {'testimonials': testimonials})

@login_required
def events(request):
    events = NetworkingEvent.objects.all()
    return render(request,'events.html',{'events':events})

def news_view(request):
    news = NewsUpdate.objects.all()
    return render(request, 'news_view.html', {'news': news})

@login_required
def add_feedback(request, pk):
    try:
        company = Student.objects.get(pk=pk)
    except Student.DoesNotExist:
        # Handle the case where the company does not exist
        return redirect('/companies')

    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback = form.save(commit=False)
            feedback.student = request.user
            feedback.company_name = company.company_name  # No error now
            feedback.save()
            messages.success(request,f'Successfully added the feedback.',extra_tags='log')
            return redirect('/companies')
    else:
        form = FeedbackForm()

    return render(request, 'feedbacks.html', {'form': form})