from django.contrib import admin
from django.urls import path
from . import views
from django.contrib.auth import views as auth_views



urlpatterns = [
    path('',views.index),

    path('home/',views.doReg,name='home'),
    path('register/', views.register, name='register'),
    path('login/',views.doLogin,name='login'),
    path('forgotpswd/',views.forgotpswd),
    path('password_change_form/',views.change_password),
    path('generate_random_password/',views.generate_random_password,name='generate_random_password'),
    path('logout/',views.logout, name='logout'),

    path('profile/',views.profile),
    path('edit_profile/',views.edit_profile),
    path('reset_password/',views.reset_password,name='password_change'),

    path('student_dashboard/', views.student_dashboard,name='student_dashboard'),
    path('about/',views.about,name='about'),
    path('contact/',views.contact,name='contact'),
    
    path('companies/', views.companies, name='companies'),
    path('company_view/<int:id>/', views.company_view, name='company_view'),
    path('apply_job/<int:job_id>/', views.apply_job, name='apply_job'),
    path('company/<int:company_id>/jobs/', views.job_list, name='job_list'),

    path('track_applications/', views.track_applications, name='track_applications'),
    path('track_application/<int:application_id>/', views.track_application_details, name='track_application_details'),
    path('confirm_interview/<int:interview_id>/', views.confirm_interview, name='confirm_interview'),
    path('cancel_interview/<int:pk>/', views.cancel_interview, name='cancel_interview'),
    path('track_interviews/', views.track_interviews, name='track_interviews'),
   
    path('testimonial_detail',views.testimonial_detail,name='testimonial_detail'),
    path('advice_detail',views.advice_detail,name='advice_detail'),
    path('job_detail',views.job_detail,name='job_detail'),
    path('story_detail',views.story_detail,name='story_detail'),
    path('events',views.events,name='events'),

    path('news_view',views.news_view,name='news_view'),
    path('add_feedback/<int:pk>', views.add_feedback, name='add_feedback'),


]
